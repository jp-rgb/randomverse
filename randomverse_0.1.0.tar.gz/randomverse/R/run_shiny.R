#' @title randomverse web app
#'
#' @description Implementation of the stochastic simulation algorithm in shiny for biological applications.
#' @author Juan Pablo Acuña González
#' @importFrom stats runif
#' @export
#' @examples
#' randomverse::RV_gui()
RV_gui = function(){
  appDir <- system.file("RV_int", package = "randomverse")

  shiny::runApp(appDir, display.mode = "normal")
}
