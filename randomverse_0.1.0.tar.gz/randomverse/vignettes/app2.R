### Load packages
library(shiny)
library(tidyverse)
library(ggplot2)
library(tidyr)
library(ggfortify)
library(magrittr)


#LV
#th1*x1,th2*x1*x2,th3*x2
#x1,x2,th1,th2,th3
#50,100,1,0.05,.6
#1,0,1,1,0,1
#2,0,0,2,0,0
#3
#2

#DK
#th1*x1*(x1-1)/2,th2*x2
#x1,x2,th1,th2
#301,0,1.66e-3,0.2
#2,0,0,1
#0,1,2,0
#2
#2

#AR
#th1*x2*x5,th2*x1,th3*x2,th4*x3,th5*0.5*x4*(x4-1),th6*x5,th7*x3,th8*x4
#x1,x2,x3,x4,x5,th1,th2,th3,th4,th5,th6,th7,th8
#0,1,2,10,12,1,10,0.01,10,1,1,0.1,0.01
#0,1,0,0,1,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,2,0,0,0,0,0,1,0,0,1,0,0,0,0,0,1,0
#1,0,0,0,0,0,1,0,0,1,0,1,1,0,0,0,0,1,1,0,0,0,0,0,1,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0
#8
#5

#MM
#th1*x1*x2,th2*x3,th3*x3
#x1,x2,x3,x4,th1,th2,th3
#301,120,0,0,0.00166,1e-04,0.1
##301,120,100,10,0.00166,1e-04,0.1
#1,1,0,0,0,0,1,0,0,0,1,0
#0,0,1,0,1,1,0,0,0,1,0,1
#3
#4

##LAC
#th1*x1,th2*x2,th3*x3*x8,th4*x8,th5*x3*x4,th6*x10,th7*x4*x5,th8*x11,th9*x11,th10*x6,th11*x8*x7,th12*x2,th13*x3,th13*x9,th14*x6,th15*x7
#x1,x2,x3,x4,x5,x6,x7,x8,x9,x10,x11,th1,th2,th3,th4,th5,th6,th7,th8,th9,th10,th11,th12,th13,th14,th15,th16
#1,0,50,1,100,0,0,20,0,0,0,0.02,0.1,0.005,0.1,1,0.01,0.1,0.01,0.03,0.1,1e-05,0.01,0.002,0.002,0.01,0.001
#1,1,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,1,1,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
#1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0
#16
#11


ui <- fluidPage(

  titlePanel(h4("An Introduction to the randomverse")),

  sidebarLayout(
    sidebarPanel(h3("Model parameters"),
      textInput("text5", label = h6("Input function body (comma delimited, no blanks)"), value = "th1*x1-th2*x1*x2,th2*x1*x2-th3*x2"),
      textInput("text6", label = h6("Input function arguments (comma delimited, no blanks)"), value = "x1,x2,th1,th2,th3"),
      textInput("text3", label = h6("Input initial markings with hazards (comma delimited, no blanks)"), value = "50,100,1,0.005,0.6"),
      textInput("text4", label = h6("Input Pre matrix (comma delimited, no blanks)"), value = "1,0,1,1,0,1"),
      textInput("text2", label = h6("Input Post matrix (comma delimited, no blanks)"), value = "2,0,0,2,0,0"),
      selectInput('NumRow',label = h6('Reactions'), choices = c(2:30),selected = 3),
      selectInput('NumCol',label = h6('Species'), choices = c(2:30),selected = 2),
      textInput("text", label = h6("Input species names (comma delimited, no blanks)"), value = "Prey,Predator"),
      textInput("title", label = h6("Input model name (comma delimited, no blanks)"), value = "Lotka-Volterra system"),
      h3("Simulation summary"),
                       numericInput("sims", label = h6("Trajectories"),2,min = 2,max = 10000),                     textInput("spec", label = h6("Select species"), value = "P"),
                       #checkboxInput("do2", "Histogram", value = F),
                       #checkboxInput("do3", "Confidence bands", value = F),
                       #checkboxInput("donum1", "Make #1 plot", value = T),
                       checkboxInput("donum2", "Histogram", value = F),
                       #checkboxInput("donum3", "Confidence bands", value = F),
                       numericInput("time", label = h6("Time horizon"),10,min = 0,max = 10000),
      checkboxInput("facet", "Facet", value = F),
      submitButton("Plot")
    ),

    mainPanel(
      tabsetPanel(
        tabPanel("Deterministic", plotOutput("det")),
        tabPanel("Stochastic", plotOutput("stoch")),
                tabPanel("Summary",
                         #plotOutput("summ")}
                         splitLayout(cellWidths = c("40%", "30%", "30%"), plotOutput("summ"), plotOutput("histo"), plotOutput("conf")))

      )
    )
  )
)

server <- function(input, output, session) {

  text_2 <- reactive({

        input$text2
      })
      text_5 <- reactive({
        input$text5
      })
      text_6 <- reactive({
        input$text6
      })
      text_3 <- reactive({
        input$text3
      })
      text_4 <- reactive({
        input$text4
      })
      title_r <- reactive({
        input$title
      })
      Num_Row <- reactive({
        input$NumRow
      })
      Num_Col <- reactive({
        input$NumCol
      })
      time_h <- reactive({
        input$time
      })
      text_n <- reactive({
        input$text
      })
      text_n <- reactive({
        input$text
      })
      sims_t <- reactive({
        input$sims
      })
      spec_n <- reactive({
        input$spec
      })


  xmat = list();
  tvec=c();
  x1=c();
  h1=c();

  output$det<-renderPlot({
    xmat = list()
    tt = 0
    tvec=c();
    h1 <- eval(eval(parse(text = paste('substitute(c(',input$text5,'), setNames(as.list(c(',input$text3,')),strsplit("',input$text6, '",split = ",")[[1]]))', sep=''))))
    x1 <- as.numeric(strsplit(input$text3,split = ",")[[1]])[1:as.numeric(input$NumCol)]
    xmat[[1]] = x1
    tvec[1] = 0
    dt = 0.001
    tt = tt + dt
    x2 <- as.numeric(strsplit(input$text3,split = ",")[[1]])[(as.numeric(input$NumCol)+1):(as.numeric(input$NumCol)+as.numeric(input$NumRow))]
    x1 = x1 + h1*dt
    xmat[[2]] = x1
    tvec[2] = tt
    i=3
    # n=as.numeric(input$time)/dt
    while(tt<input$time) {
      #for (i in 3:input$time) {
      x1 <- paste(c(x1,x2),collapse = ",")
      h1 <- eval(eval(parse(text = paste('substitute(c(',input$text5,'), setNames(as.list(c(',x1,')),strsplit("',input$text6, '",split = ",")[[1]]))', sep=''))))
      x1 <- as.numeric(strsplit(x1,split = ",")[[1]])[1:as.numeric(input$NumCol)]
      x1 = x1 + h1*dt
      tt = tt + dt
      xmat[[i]] = x1
      tvec[i] = tt
      tt=tvec[i]
      i=i+1
    }
    xmat = t(as.data.frame(xmat,row.names = strsplit(input$text,split = ",")[[1]]))
    data_long <- gather(cbind(tvec,as.data.frame(ts(xmat))),
                        species,
                        molecules,
                        colnames(xmat), factor_key=TRUE)
  plot(ts(xmat))
        # ggplot(data_long, aes(x = tvec, y = molecules, color = species)) +
    # geom_line() +
    # labs(x = "Time", y = "Simulation Value")
  }
  )
  xmat = list();
  tvec=c();
  x1=c();
  h1=c();

  output$stoch<-renderPlot({
    xmat = list()
    tt = 0
    tvec=c();
    S <- t(matrix(as.numeric(strsplit(input$text2, split = ",")[[1]])-as.numeric(strsplit(input$text4, split = ",")[[1]]),ncol = as.numeric(input$NumCol) ,nrow = as.numeric(input$NumRow),byrow=TRUE))
    h1 <- eval(eval(parse(text = paste('substitute(c(',input$text5,'), setNames(as.list(c(',input$text3,')),strsplit("',input$text6, '",split = ",")[[1]]))', sep=''))))
    x1 <- as.numeric(strsplit(input$text3,split = ",")[[1]])[1:as.numeric(input$NumCol)]
    xmat[[1]] = x1
    tvec[1] = 0
    tt = tt + rexp(1, sum(h1))
    x2 <- as.numeric(strsplit(input$text3,split = ",")[[1]])[(as.numeric(input$NumCol)+1):(as.numeric(input$NumCol)+as.numeric(input$NumRow))]
    j1 <- sample(as.numeric(input$NumRow), 1, prob = h1)
    x1 = x1 + S[, j1]
    xmat[[2]] <- x1
    tvec[2] = tt
    i=3
    while(tt<input$time) {
      #for (i in 3:input$time) {
      x1 <- paste(c(x1,x2),collapse = ",")
      h1 <- eval(eval(parse(text = paste('substitute(c(',input$text5,'), setNames(as.list(c(',x1,')),strsplit("',input$text6, '",split = ",")[[1]]))', sep=''))))
      tt = tt + rexp(1, sum(h1))
      j1 <- sample(as.numeric(input$NumRow), 1, prob = h1)
      x1 <- as.numeric(strsplit(x1,split = ",")[[1]])[1:as.numeric(input$NumCol)]
      x1 = x1 + S[, j1]
      xmat[[i]] <- x1
      tvec[i] = tt
      tt=tvec[i]
      i=i+1
    }
    xmat = t(as.data.frame(xmat,row.names = strsplit(input$text,split = ",")[[1]]))
    data_long <- gather(cbind(tvec,as.data.frame(ts(xmat))),
                        species,
                        molecules,
                        colnames(xmat), factor_key=TRUE)
    plot(ts(xmat))
      # ggplot(data_long,aes(x = tvec, y = molecules, color = species)) +
      # geom_point() +
      # labs(x = "Time", y = "Simulation Value")
  }
  )

  pt2 <- reactive({
    if (!input$donum2) return(NULL)
    #qplot(rnorm(500),fill=I("blue"),binwidth=0.2,main="plotgraph2")
        BM <- list()
        xmat <- list()
        tt <- 0
        tvec <- c();
        S <- t(matrix(as.numeric(strsplit(input$text2, split = ",")[[1]])-as.numeric(strsplit(input$text4, split = ",")[[1]]),ncol = as.numeric(input$NumCol) ,nrow = as.numeric(input$NumRow),byrow=TRUE))
        h1 <- eval(eval(parse(text = paste('substitute(c(',input$text5,'), setNames(as.list(c(',input$text3,')),strsplit("',input$text6, '",split = ",")[[1]]))', sep=''))))
        x1 <- as.numeric(strsplit(input$text3,split = ",")[[1]])[1:as.numeric(input$NumCol)]
        xmat[[1]] <- x1
        tvec[1] <- 0
        tt <- tt + rexp(1, sum(h1))
        x2 <- as.numeric(strsplit(input$text3,split = ",")[[1]])[(as.numeric(input$NumCol)+1):(as.numeric(input$NumCol)+as.numeric(input$NumRow))]
        j1 <- sample(as.numeric(input$NumRow), 1, prob = h1)
        x1 <- x1 + S[, j1]
        xmat[[2]] <- x1
        tvec[2] <- tt
        i <- 3
        while(tt < input$time) {
          #for (i in 3:input$time) {
          x1 <- paste(c(x1,x2),collapse = ",")
          h1 <- eval(eval(parse(text = paste('substitute(c(',input$text5,'), setNames(as.list(c(',x1,')),strsplit("',input$text6, '",split = ",")[[1]]))', sep=''))))
          tt <- tt + rexp(1, sum(h1))
          j1 <- sample(as.numeric(input$NumRow), 1, prob = h1)
          x1 <- as.numeric(strsplit(x1,split = ",")[[1]])[1:as.numeric(input$NumCol)]
          x1 <- x1 + S[, j1]
          xmat[[i]] <- x1
          tvec[i] <- tt
          tt <- tvec[i]
          i <- i+1
          }
        xmat <- t(as.data.frame(xmat,row.names = strsplit(input$text,split = ",")[[1]]))
        BM <- list(a=as.integer(tail(xmat[,input$spec],1)))
        j <- 1
        for (j in 1:(as.numeric(input$sims)-1)){
          xmat <- list()
          tt <- 0
          tvec <- c();
          S <- t(matrix(as.numeric(strsplit(input$text2, split = ",")[[1]])-as.numeric(strsplit(input$text4, split = ",")[[1]]),ncol = as.numeric(input$NumCol) ,nrow = as.numeric(input$NumRow),byrow=TRUE))
          h1 <- eval(eval(parse(text = paste('substitute(c(',input$text5,'), setNames(as.list(c(',input$text3,')),strsplit("',input$text6, '",split = ",")[[1]]))', sep=''))))
          x1 <- as.numeric(strsplit(input$text3,split = ",")[[1]])[1:as.numeric(input$NumCol)]
          xmat[[1]] <- x1
          tvec[1] <- 0
          tt <- tt + rexp(1, sum(h1))
          x2 <- as.numeric(strsplit(input$text3,split = ",")[[1]])[(as.numeric(input$NumCol)+1):(as.numeric(input$NumCol)+as.numeric(input$NumRow))]
          j1 <- sample(as.numeric(input$NumRow), 1, prob = h1)
          x1 <- x1 + S[, j1]
          xmat[[2]] <- x1
          tvec[2] <- tt
          i <- 3
          while(tt < input$time) {
            #for (i in 3:input$time) {
            x1 <- paste(c(x1,x2),collapse = ",")
            h1 <- eval(eval(parse(text = paste('substitute(c(',input$text5,'), setNames(as.list(c(',x1,')),strsplit("',input$text6, '",split = ",")[[1]]))', sep=''))))
            tt <- tt + rexp(1, sum(h1))
            j1 <- sample(as.numeric(input$NumRow), 1, prob = h1)
            x1 <- as.numeric(strsplit(x1,split = ",")[[1]])[1:as.numeric(input$NumCol)]
            x1 <- x1 + S[, j1]
            xmat[[i]] <- x1
            tvec[i] <- tt
            tt <- tvec[i]
            i <- i+1
            }
          xmat <- t(as.data.frame(xmat,row.names = strsplit(input$text,split = ",")[[1]]))
          BM <- append(BM,list(a=as.integer(tail(xmat[,input$spec],1))))
          j <- j+1
          }
          #return(
        hist(unlist(BM),freq = FALSE, xlab = "# Molecules", main = paste("Histogram of" , spec_n()))
        #)
    })

  output$summ <- renderPlot({
    BM <- list();
    xmat <- list()
    tt <- 0
    tvec <- c();
    S <- t(matrix(as.numeric(strsplit(text_2(), split = ",")[[1]])-as.numeric(strsplit(text_4(), split = ",")[[1]]),ncol = as.numeric(Num_Col()) ,nrow = as.numeric(Num_Row()),byrow=TRUE))
    h1 <- eval(eval(parse(text = paste('substitute(c(',text_5(),'), setNames(as.list(c(',text_3(),')),strsplit("',text_6(), '",split = ",")[[1]]))', sep=''))))
    x1 <- as.numeric(strsplit(text_3(),split = ",")[[1]])[1:as.numeric(Num_Col())]
    xmat[[1]] <- x1
    tvec[1] <- 0
    tt <- tt + rexp(1, sum(h1))
    x2 <- as.numeric(strsplit(text_3(),split = ",")[[1]])[(as.numeric(Num_Col())+1):(as.numeric(Num_Col())+as.numeric(Num_Row()))]
    j1 <- sample(as.numeric(Num_Row()), 1, prob = h1)
    x1 <- x1 + S[, j1]
    xmat[[2]] <- x1
    tvec[2] <- tt
    i <- 3
    while(tt < time_h()) {
      #for (i in 3:input$time) {
      x1 <- paste(c(x1,x2),collapse = ",")
      h1 <- eval(eval(parse(text = paste('substitute(c(',text_5(),'), setNames(as.list(c(',x1,')),strsplit("',text_6(), '",split = ",")[[1]]))', sep=''))))
      tt <- tt + rexp(1, sum(h1))
      j1 <- sample(as.numeric(Num_Row()), 1, prob = h1)
      x1 <- as.numeric(strsplit(x1,split = ",")[[1]])[1:as.numeric(Num_Col())]
      x1 <- x1 + S[, j1]
      xmat[[i]] <- x1
      tvec[i] <- tt
      tt <- tvec[i]
      i <- i+1
      }
    xmat <- t(as.data.frame(xmat,row.names = strsplit(text_n(),split = ",")[[1]]))
    BM <- list(a=as.integer(xmat[,spec_n()]))
    j <- 1
    for (j in 1:(as.numeric(sims_t())-1)){
      xmat <- list()
      tt <- 0
      tvec <- c();
      S <- t(matrix(as.numeric(strsplit(text_2(), split = ",")[[1]])-as.numeric(strsplit(text_4(), split = ",")[[1]]),ncol = as.numeric(Num_Col()) ,nrow = as.numeric(Num_Row()),byrow=TRUE))
      h1 <- eval(eval(parse(text = paste('substitute(c(',text_5(),'), setNames(as.list(c(',text_3(),')),strsplit("',text_6(), '",split = ",")[[1]]))', sep=''))))
      x1 <- as.numeric(strsplit(text_3(),split = ",")[[1]])[1:as.numeric(Num_Col())]
      xmat[[1]] <- x1
      tvec[1] <- 0
      tt <- tt + rexp(1, sum(h1))
      x2 <- as.numeric(strsplit(text_3(),split = ",")[[1]])[(as.numeric(Num_Col())+1):(as.numeric(Num_Col())+as.numeric(Num_Row()))]
      j1 <- sample(as.numeric(Num_Row()), 1, prob = h1)
      x1 <- x1 + S[, j1]
      xmat[[2]] <- x1
      tvec[2] <- tt
      i <- 3
      while(tt < time_h()) {
        #for (i in 3:input$time) {
        x1 <- paste(c(x1,x2),collapse = ",")
        h1 <- eval(eval(parse(text = paste('substitute(c(',text_5(),'), setNames(as.list(c(',x1,')),strsplit("',text_6(), '",split = ",")[[1]]))', sep=''))))
        tt <- tt + rexp(1, sum(h1))
        j1 <- sample(as.numeric(Num_Row()), 1, prob = h1)
        x1 <- as.numeric(strsplit(x1,split = ",")[[1]])[1:as.numeric(Num_Col())]
        x1 <- x1 + S[, j1]
        xmat[[i]] <- x1
        tvec[i] <- tt
        tt <- tvec[i]
        i <- i+1
        }
      xmat <- t(as.data.frame(xmat,row.names = strsplit(text_n(),split = ",")[[1]]))
      BM <- append(BM,list(a=as.integer(xmat[,spec_n()])))
      j <- j+1
      }
    plot(unlist(BM),type="n",xlim=c(1,max(sapply(BM,length))),xlab="# Reactions",ylab=input$spec, main=title_r())
    rect(par("usr")[1], par("usr")[3],
         par("usr")[2], par("usr")[4],
         col = "#ebebeb")
    # Grid blanco
    grid(nx = NULL, ny = NULL,
         col = "white", lwd = 2)
    mapply(lines,BM,col=seq_along(BM),lty=2)})
    output$histo = renderPlot({pt2()})
}

shinyApp(ui = ui, server = server)



# ### Load packages
# library(shiny)
# #library(tidyverse)
# library(ggplot2)
# library(ggfortify)
# library(matrixStats)
# library(gridExtra)
#
#
# #LV
# #th1*x1,th2*x1*x2,th3*x2
# #x1,x2,th1,th2,th3
# #50,100,1,0.05,.6
# #1,0,1,1,0,1
# #2,0,0,2,0,0
# #3
# #2
#
# #DK
# #th1*x1*(x1-1)/2,th2*x2
# #x1,x2,th1,th2
# #301,0,1.66e-3,0.2
# #2,0,0,1
# #0,1,2,0
# #2
# #2
#
# #AR
# #th1*x2*x5,th2*x1,th3*x2,th4*x3,th5*0.5*x4*(x4-1),th6*x5,th7*x3,th8*x4
# #x1,x2,x3,x4,x5,th1,th2,th3,th4,th5,th6,th7,th8
# #0,1,2,10,12,1,10,0.01,10,1,1,0.1,0.01
# #0,1,0,0,1,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,2,0,0,0,0,0,1,0,0,1,0,0,0,0,0,1,0
# #1,0,0,0,0,0,1,0,0,1,0,1,1,0,0,0,0,1,1,0,0,0,0,0,1,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0
# #8
# #5
#
# #MM
# #th1*x1*x2,th2*x3,th3*x3
# #x1,x2,x3,x4,th1,th2,th3
# #301,120,0,0,0.00166,1e-04,0.1
# ##301,120,100,10,0.00166,1e-04,0.1
# #1,1,0,0,0,0,1,0,0,0,1,0
# #0,0,1,0,1,1,0,0,0,1,0,1
# #3
# #4
#
# ##LAC
# #th1*x1,th2*x2,th3*x3*x8,th4*x8,th5*x3*x4,th6*x10,th7*x4*x5,th8*x11,th9*x11,th10*x6,th11*x8*x7,th12*x2,th13*x3,th13*x9,th14*x6,th15*x7
# #x1,x2,x3,x4,x5,x6,x7,x8,x9,x10,x11,th1,th2,th3,th4,th5,th6,th7,th8,th9,th10,th11,th12,th13,th14,th15,th16
# #1,0,50,1,100,0,0,20,0,0,0,0.02,0.1,0.005,0.1,1,0.01,0.1,0.01,0.03,0.1,1e-05,0.01,0.002,0.002,0.01,0.001
# #1,1,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,1,1,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
# #1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0
# #16
# #11
#
#
# ui <- fluidPage(
#
#   titlePanel(h4("An Introduction to the randomverse")),
#
#   sidebarLayout(
#     sidebarPanel(h3("Model parameters"),
#                  textInput("text5", label = h6("Input function body (comma delimited, no blanks)"), value = "th1*x1-th2*x1*x2,th2*x1*x2-th3*x2"),
#                  textInput("text6", label = h6("Input function arguments (comma delimited, no blanks)"), value = "x1,x2,th1,th2,th3"),
#                  textInput("text3", label = h6("Input initial markings with hazards (comma delimited, no blanks)"), value = "50,100,1,0.005,0.6"),
#                  textInput("text4", label = h6("Input Pre matrix (comma delimited, no blanks)"), value = "1,0,1,1,0,1"),
#                  textInput("text2", label = h6("Input Post matrix (comma delimited, no blanks)"), value = "2,0,0,2,0,0"),
#                  selectInput('NumRow',label = h6('Reactions'), choices = c(2:20),selected = 3),
#                  selectInput('NumCol',label = h6('Species'), choices = c(2:20),selected = 2),
#                  textInput("text", label = h6("Input species names (comma delimited, no blanks)"), value = "Prey,Predator"),
#                  textInput("title", label = h6("Input model name"), value = "Lotka-Volterra System"),
#                  checkboxInput("view", h6("Facets"), value = FALSE, width = NULL),
#                  h3("Simulation analysis"),
#                  numericInput("sims", label = h6("Trajectories"),2,min = 2,max = 10000),                     textInput("spec", label = h6("Select species"), value = "P"),
#                  #checkboxInput("do2", "Histogram", value = F),
#                  #checkboxInput("do3", "Confidence bands", value = F),
#                  #checkboxInput("donum1", "Make #1 plot", value = T),
#                  checkboxInput("donum2", "Histogram", value = F),
#                  checkboxInput("donum3", "Confidence bands", value = F),
#                  numericInput("time", label = h6("Time horizon"),10,min = 0,max = 10000),
#                  submitButton("Plot")
#                  ),
#
#     mainPanel(
#       tabsetPanel(
#         tabPanel("Deterministic", plotOutput("det")),
#         tabPanel("Stochastic", plotOutput("stoch")),
#         tabPanel("Summary",
#                  #plotOutput("summ")}
#                  splitLayout(cellWidths = c("40%", "30%", "30%"), plotOutput("summ"), plotOutput("histo"), plotOutput("conf")))
#         )
#       )
#
#     )
#
#   )
#
# server <- shinyServer(function(input, output)
# {#function(input, output, session) {
#
#   text_2 <- reactive({
#     input$text2
#   })
#   text_5 <- reactive({
#     input$text5
#   })
#   text_6 <- reactive({
#     input$text6
#   })
#   text_3 <- reactive({
#     input$text3
#   })
#   text_4 <- reactive({
#     input$text4
#   })
#   title_r <- reactive({
#     input$title
#   })
#   Num_Row <- reactive({
#     input$NumRow
#   })
#   Num_Col <- reactive({
#     input$NumCol
#   })
#   time_h <- reactive({
#     input$time
#   })
#   text_n <- reactive({
#     input$text
#   })
#   text_n <- reactive({
#     input$text
#   })
#   sims_t <- reactive({
#     input$sims
#   })
#   spec_n <- reactive({
#     input$spec
#   })
#
# xmat <- list();
# tvec <- c();
# x1 <- c();
# h1 <- c();
# output$det <- renderPlot({
#     xmat <- list()
#     tt <- 0
#     tvec <- c();
#     h1 <- eval(eval(parse(text = paste('substitute(c(',text_5(),'), setNames(as.list(c(',text_3(),')),strsplit("',text_6(), '",split = ",")[[1]]))', sep=''))))
#     x1 <- as.numeric(strsplit(text_3(),split = ",")[[1]])[1:as.numeric(Num_Col())]
#     xmat[[1]] <- x1
#     tvec[1] <- 0
#     dt <- 0.001
#     tt <- tt + dt
#     x2 <- as.numeric(strsplit(text_3(),split = ",")[[1]])[(as.numeric(Num_Col())+1):(as.numeric(Num_Col())+as.numeric(Num_Row()))]
#     x1 <- x1 + h1*dt
#     xmat[[2]] <- x1
#     tvec[2] <- tt
#     i <- 3
#     # n=as.numeric(input$time)/dt
#     while(tt < input$time) {
#       #for (i in 3:input$time) {
#       x1 <- paste(c(x1,x2),collapse = ",")
#       h1 <- eval(eval(parse(text = paste('substitute(c(',text_5(),'), setNames(as.list(c(',x1,')),strsplit("',text_6(), '",split = ",")[[1]]))', sep=''))))
#       x1 <- as.numeric(strsplit(x1,split = ",")[[1]])[1:as.numeric(Num_Col())]
#       x1 <- x1 + h1*dt
#       tt <- tt + dt
#       xmat[[i]] <- x1
#       tvec[i] <- tt
#       tt <- tvec[i]
#       i <- i+1
#     }
#     xmat <- t(as.data.frame(xmat,row.names = strsplit(input$text,split = ",")[[1]]))
#     autoplot(ts(xmat),facets = input$view, main= input$title)
#     }
#   )
#
# xmat <- list();
# tvec <- c();
# x1 <- c();
# h1 <- c();
# output$stoch <- renderPlot({
#     BM <- list()
#     xmat <- list()
#     tt <- 0
#     tvec <- c();
#     S <- t(matrix(as.numeric(strsplit(text_2(), split = ",")[[1]])-as.numeric(strsplit(text_4(), split = ",")[[1]]),ncol = as.numeric(Num_Col()) ,nrow = as.numeric(Num_Row()),byrow=TRUE))
#     h1 <- eval(eval(parse(text = paste('substitute(c(',text_5(),'), setNames(as.list(c(',text_3(),')),strsplit("',text_6(), '",split = ",")[[1]]))', sep=''))))
#     x1 <- as.numeric(strsplit(text_3(),split = ",")[[1]])[1:as.numeric(Num_Col())]
#     xmat[[1]] <- x1
#     tvec[1] <- 0
#     tt <- tt + rexp(1, sum(h1))
#     x2 <- as.numeric(strsplit(text_3(),split = ",")[[1]])[(as.numeric(input$NumCol)+1):(as.numeric(input$NumCol)+as.numeric(input$NumRow))]
#     j1 <- sample(as.numeric(input$NumRow), 1, prob = h1)
#     x1 <- x1 + S[, j1]
#     xmat[[2]] <- x1
#     tvec[2] <- tt
#     i <- 3
#     while(tt < input$time) {
#       #for (i in 3:input$time) {
#       x1 <- paste(c(x1,x2),collapse = ",")
#       h1 <- eval(eval(parse(text = paste('substitute(c(',text_5(),'), setNames(as.list(c(',x1,')),strsplit("',text_6(), '",split = ",")[[1]]))', sep=''))))
#       tt <- tt + rexp(1, sum(h1))
#       j1 <- sample(as.numeric(input$NumRow), 1, prob = h1)
#       x1 <- as.numeric(strsplit(x1,split = ",")[[1]])[1:as.numeric(input$NumCol)]
#       x1 <- x1 + S[, j1]
#       xmat[[i]] <- x1
#       tvec[i] <- tt
#       tt <- tvec[i]
#       i <- i+1
#     }
#     xmat <- t(as.data.frame(xmat,row.names = strsplit(input$text,split = ",")[[1]]))
#     autoplot(ts(xmat),facets = input$view, main=input$title)
#   }
#   )
#
# pt2 <- reactive({
#   if (!input$donum2) return(NULL)
#   #qplot(rnorm(500),fill=I("blue"),binwidth=0.2,main="plotgraph2")
#       BM <- list()
#       xmat <- list()
#       tt <- 0
#       tvec <- c();
#       S <- t(matrix(as.numeric(strsplit(input$text2, split = ",")[[1]])-as.numeric(strsplit(input$text4, split = ",")[[1]]),ncol = as.numeric(input$NumCol) ,nrow = as.numeric(input$NumRow),byrow=TRUE))
#       h1 <- eval(eval(parse(text = paste('substitute(c(',input$text5,'), setNames(as.list(c(',input$text3,')),strsplit("',input$text6, '",split = ",")[[1]]))', sep=''))))
#       x1 <- as.numeric(strsplit(input$text3,split = ",")[[1]])[1:as.numeric(input$NumCol)]
#       xmat[[1]] <- x1
#       tvec[1] <- 0
#       tt <- tt + rexp(1, sum(h1))
#       x2 <- as.numeric(strsplit(input$text3,split = ",")[[1]])[(as.numeric(input$NumCol)+1):(as.numeric(input$NumCol)+as.numeric(input$NumRow))]
#       j1 <- sample(as.numeric(input$NumRow), 1, prob = h1)
#       x1 <- x1 + S[, j1]
#       xmat[[2]] <- x1
#       tvec[2] <- tt
#       i <- 3
#       while(tt < input$time) {
#         #for (i in 3:input$time) {
#         x1 <- paste(c(x1,x2),collapse = ",")
#         h1 <- eval(eval(parse(text = paste('substitute(c(',input$text5,'), setNames(as.list(c(',x1,')),strsplit("',input$text6, '",split = ",")[[1]]))', sep=''))))
#         tt <- tt + rexp(1, sum(h1))
#         j1 <- sample(as.numeric(input$NumRow), 1, prob = h1)
#         x1 <- as.numeric(strsplit(x1,split = ",")[[1]])[1:as.numeric(input$NumCol)]
#         x1 <- x1 + S[, j1]
#         xmat[[i]] <- x1
#         tvec[i] <- tt
#         tt <- tvec[i]
#         i <- i+1
#         }
#       xmat <- t(as.data.frame(xmat,row.names = strsplit(input$text,split = ",")[[1]]))
#       BM <- list(a=as.integer(tail(xmat[,input$spec],1)))
#       j <- 1
#       for (j in 1:(as.numeric(input$sims)-1)){
#         xmat <- list()
#         tt <- 0
#         tvec <- c();
#         S <- t(matrix(as.numeric(strsplit(input$text2, split = ",")[[1]])-as.numeric(strsplit(input$text4, split = ",")[[1]]),ncol = as.numeric(input$NumCol) ,nrow = as.numeric(input$NumRow),byrow=TRUE))
#         h1 <- eval(eval(parse(text = paste('substitute(c(',input$text5,'), setNames(as.list(c(',input$text3,')),strsplit("',input$text6, '",split = ",")[[1]]))', sep=''))))
#         x1 <- as.numeric(strsplit(input$text3,split = ",")[[1]])[1:as.numeric(input$NumCol)]
#         xmat[[1]] <- x1
#         tvec[1] <- 0
#         tt <- tt + rexp(1, sum(h1))
#         x2 <- as.numeric(strsplit(input$text3,split = ",")[[1]])[(as.numeric(input$NumCol)+1):(as.numeric(input$NumCol)+as.numeric(input$NumRow))]
#         j1 <- sample(as.numeric(input$NumRow), 1, prob = h1)
#         x1 <- x1 + S[, j1]
#         xmat[[2]] <- x1
#         tvec[2] <- tt
#         i <- 3
#         while(tt < input$time) {
#           #for (i in 3:input$time) {
#           x1 <- paste(c(x1,x2),collapse = ",")
#           h1 <- eval(eval(parse(text = paste('substitute(c(',input$text5,'), setNames(as.list(c(',x1,')),strsplit("',input$text6, '",split = ",")[[1]]))', sep=''))))
#           tt <- tt + rexp(1, sum(h1))
#           j1 <- sample(as.numeric(input$NumRow), 1, prob = h1)
#           x1 <- as.numeric(strsplit(x1,split = ",")[[1]])[1:as.numeric(input$NumCol)]
#           x1 <- x1 + S[, j1]
#           xmat[[i]] <- x1
#           tvec[i] <- tt
#           tt <- tvec[i]
#           i <- i+1
#           }
#         xmat <- t(as.data.frame(xmat,row.names = strsplit(input$text,split = ",")[[1]]))
#         BM <- append(BM,list(a=as.integer(tail(xmat[,input$spec],1))))
#         j <- j+1
#         }
#         #return(
#       hist(unlist(BM),freq = FALSE, xlab = "# Molecules", main = paste("Histogram of" , spec_n()))
#       #)
#   })
#   # pt3 <- reactive({
#   #   if (!input$donum3) return(NULL)
#   #         BM <- list()
#   #         BM2 <- list()
#   #         BM3 <- list()
#   #         xmat <- list()
#   #         tt <- 0
#   #         tvec <- c();
#   #         S <- t(matrix(as.numeric(strsplit(input$text2, split = ",")[[1]])-as.numeric(strsplit(input$text4, split = ",")[[1]]),ncol = as.numeric(input$NumCol) ,nrow = as.numeric(input$NumRow),byrow=TRUE))
#   #         h1 <- eval(eval(parse(text = paste('substitute(c(',input$text5,'), setNames(as.list(c(',input$text3,')),strsplit("',input$text6, '",split = ",")[[1]]))', sep=''))))
#   #         x1 <- as.numeric(strsplit(input$text3,split = ",")[[1]])[1:as.numeric(input$NumCol)]
#   #         xmat[[1]] <- x1
#   #         tvec[1] <- 0
#   #         tt <- tt + rexp(1, sum(h1))
#   #         x2 <- as.numeric(strsplit(input$text3,split = ",")[[1]])[(as.numeric(input$NumCol)+1):(as.numeric(input$NumCol)+as.numeric(input$NumRow))]
#   #         j1 <- sample(as.numeric(input$NumRow), 1, prob = h1)
#   #         x1 <- x1 + S[, j1]
#   #         xmat[[2]] <- x1
#   #         tvec[2] <- tt
#   #         i <- 3
#   #         while(tt < input$time) {
#   #           #for (i in 3:input$time) {
#   #           x1 <- paste(c(x1,x2),collapse = ",")
#   #           h1 <- eval(eval(parse(text = paste('substitute(c(',input$text5,'), setNames(as.list(c(',x1,')),strsplit("',input$text6, '",split = ",")[[1]]))', sep=''))))
#   #           tt <- tt + rexp(1, sum(h1))
#   #           j1 <- sample(as.numeric(input$NumRow), 1, prob = h1)
#   #           x1 <- as.numeric(strsplit(x1,split = ",")[[1]])[1:as.numeric(input$NumCol)]
#   #           x1 <- x1 + S[, j1]
#   #           xmat[[i]] <- x1
#   #           tvec[i] <- tt
#   #           tt <- tvec[i]
#   #           i <- i+1
#   #         }
#   #         xmat <- t(as.data.frame(xmat,row.names = strsplit(input$text,split = ",")[[1]]))
#   #         BM <- list(a=as.integer(tail(xmat[,input$spec],1)))
#   #         j <- 1
#   #         for (j in 1:(as.numeric(input$sims)-1)){
#   #           xmat <- list()
#   #           tt <- 0
#   #           tvec <- c();
#   #           S <- t(matrix(as.numeric(strsplit(input$text2, split = ",")[[1]])-as.numeric(strsplit(input$text4, split = ",")[[1]]),ncol = as.numeric(input$NumCol) ,nrow = as.numeric(input$NumRow),byrow=TRUE))
#   #           h1 <- eval(eval(parse(text = paste('substitute(c(',input$text5,'), setNames(as.list(c(',input$text3,')),strsplit("',input$text6, '",split = ",")[[1]]))', sep=''))))
#   #           x1 <- as.numeric(strsplit(input$text3,split = ",")[[1]])[1:as.numeric(input$NumCol)]
#   #           xmat[[1]] <- x1
#   #           tvec[1] <- 0
#   #           tt <- tt + rexp(1, sum(h1))
#   #           x2 <- as.numeric(strsplit(input$text3,split = ",")[[1]])[(as.numeric(input$NumCol)+1):(as.numeric(input$NumCol)+as.numeric(input$NumRow))]
#   #           j1 <- sample(as.numeric(input$NumRow), 1, prob = h1)
#   #           x1 <- x1 + S[, j1]
#   #           xmat[[2]] <- x1
#   #           tvec[2] <- tt
#   #           i <- 3
#   #           while(tt < input$time) {
#   #             #for (i in 3:input$time) {
#   #             x1 <- paste(c(x1,x2),collapse = ",")
#   #             h1 <- eval(eval(parse(text = paste('substitute(c(',input$text5,'), setNames(as.list(c(',x1,')),strsplit("',input$text6, '",split = ",")[[1]]))', sep=''))))
#   #             tt <- tt + rexp(1, sum(h1))
#   #             j1 <- sample(as.numeric(input$NumRow), 1, prob = h1)
#   #             x1 <- as.numeric(strsplit(x1,split = ",")[[1]])[1:as.numeric(input$NumCol)]
#   #             x1 <- x1 + S[, j1]
#   #             xmat[[i]] <- x1
#   #             tvec[i] <- tt
#   #             tt <- tvec[i]
#   #             i <- i+1
#   #           }
#   #           xmat <- t(as.data.frame(xmat,row.names = strsplit(input$text,split = ",")[[1]]))
#   #           BM <- append(BM,list(a=as.integer(tail(xmat[,input$spec],1))))
#   #           j <- j+1
#   #         }
#   #
#   #         # BM2<-lapply(BM, `length<-`, min(lengths(BM)))
#   #         # #BM3<-list(colMeans(do.call(rbind,BM2)))
#   #         # #plot(unlist(BM3),type="n",xlim=c(1,max(sapply(BM3,length))),xlab="# Reactions",ylab=input$spec, main=title_r())
#   #         # return(
#   #         #
#   #         # # BM3<-append(BM3,list(colMeans(do.call(rbind,BM2))-3*colSds(do.call(rbind,BM2))));
#   #         # # BM3<-append(BM3,list(colMeans(do.call(rbind,BM2))+3*colSds(do.call(rbind,BM2))));
#   #         # hist(unlist(BM2),freq = FALSE, xlab = "Upper band", main = paste("Histogram of" , spec_n()))
#   #         #
#   #         # # rect(par("usr")[1], par("usr")[3],
#   #         # #      par("usr")[2], par("usr")[4],
#   #         # #      col = "#ebebeb")
#   #         # # Grid blanco
#   #         # # grid(nx = NULL, ny = NULL,
#   #         # #      col = "white", lwd = 2)
#   #         # #mapply(lines,BM2,col=seq_along(BM2),lty=2)
#   #         # )
#   #         # plot(unlist(BM3),type="n",xlim=c(1,max(sapply(BM3,length))),xlab="# Reactions",ylab=input$spec);
#   #         # rect(par("usr")[1], par("usr")[3],
#   #         #      par("usr")[2], par("usr")[4],
#   #         #      col = "#ebebeb");
#   #         # # Grid blanco
#   #         # grid(nx = NULL, ny = NULL,
#   #         #      col = "white", lwd = 2);
#   #         # mapply(lines,BM3,col=seq_along(BM3),lty=2);
#   #         # legend("topleft",legend=c("Sample mean", "Sample mean minus 3 sample SDs", "Sample mean plus 3 sample SDs"), col=c("black", "red", "green"),lty=2, cex=0.4,bg="#ebebeb")
#   #
#   # })
# # pt3 <- reactive({
# #   input$do2
# #   if (input$do2){
# #     BM <- list()
# #     xmat <- list()
# #     tt <- 0
# #     tvec <- c();
# #     S <- t(matrix(as.numeric(strsplit(input$text2, split = ",")[[1]])-as.numeric(strsplit(input$text4, split = ",")[[1]]),ncol = as.numeric(input$NumCol) ,nrow = as.numeric(input$NumRow),byrow=TRUE))
# #     h1 <- eval(eval(parse(text = paste('substitute(c(',input$text5,'), setNames(as.list(c(',input$text3,')),strsplit("',input$text6, '",split = ",")[[1]]))', sep=''))))
# #     x1 <- as.numeric(strsplit(input$text3,split = ",")[[1]])[1:as.numeric(input$NumCol)]
# #     xmat[[1]] <- x1
# #     tvec[1] <- 0
# #     tt <- tt + rexp(1, sum(h1))
# #     x2 <- as.numeric(strsplit(input$text3,split = ",")[[1]])[(as.numeric(input$NumCol)+1):(as.numeric(input$NumCol)+as.numeric(input$NumRow))]
# #     j1 <- sample(as.numeric(input$NumRow), 1, prob = h1)
# #     x1 <- x1 + S[, j1]
# #     xmat[[2]] <- x1
# #     tvec[2] <- tt
# #     i <- 3
# #     while(tt < input$time) {
# #       #for (i in 3:input$time) {
# #       x1 <- paste(c(x1,x2),collapse = ",")
# #       h1 <- eval(eval(parse(text = paste('substitute(c(',input$text5,'), setNames(as.list(c(',x1,')),strsplit("',input$text6, '",split = ",")[[1]]))', sep=''))))
# #       tt <- tt + rexp(1, sum(h1))
# #       j1 <- sample(as.numeric(input$NumRow), 1, prob = h1)
# #       x1 <- as.numeric(strsplit(x1,split = ",")[[1]])[1:as.numeric(input$NumCol)]
# #       x1 <- x1 + S[, j1]
# #       xmat[[i]] <- x1
# #       tvec[i] <- tt
# #       tt <- tvec[i]
# #       i <- i+1
# #       }
# #     xmat <- t(as.data.frame(xmat,row.names = strsplit(input$text,split = ",")[[1]]))
# #     BM <- list(a=as.integer(tail(xmat[,input$spec],1)))
# #     j <- 1
# #     for (j in 1:(as.numeric(input$sims)-1)){
# #       xmat <- list()
# #       tt <- 0
# #       tvec <- c();
# #       S <- t(matrix(as.numeric(strsplit(input$text2, split = ",")[[1]])-as.numeric(strsplit(input$text4, split = ",")[[1]]),ncol = as.numeric(input$NumCol) ,nrow = as.numeric(input$NumRow),byrow=TRUE))
# #       h1 <- eval(eval(parse(text = paste('substitute(c(',input$text5,'), setNames(as.list(c(',input$text3,')),strsplit("',input$text6, '",split = ",")[[1]]))', sep=''))))
# #       x1 <- as.numeric(strsplit(input$text3,split = ",")[[1]])[1:as.numeric(input$NumCol)]
# #       xmat[[1]] <- x1
# #       tvec[1] <- 0
# #       tt <- tt + rexp(1, sum(h1))
# #       x2 <- as.numeric(strsplit(input$text3,split = ",")[[1]])[(as.numeric(input$NumCol)+1):(as.numeric(input$NumCol)+as.numeric(input$NumRow))]
# #       j1 <- sample(as.numeric(input$NumRow), 1, prob = h1)
# #       x1 <- x1 + S[, j1]
# #       xmat[[2]] <- x1
# #       tvec[2] <- tt
# #       i <- 3
# #       while(tt < input$time) {
# #         #for (i in 3:input$time) {
# #         x1 <- paste(c(x1,x2),collapse = ",")
# #         h1 <- eval(eval(parse(text = paste('substitute(c(',input$text5,'), setNames(as.list(c(',x1,')),strsplit("',input$text6, '",split = ",")[[1]]))', sep=''))))
# #         tt <- tt + rexp(1, sum(h1))
# #         j1 <- sample(as.numeric(input$NumRow), 1, prob = h1)
# #         x1 <- as.numeric(strsplit(x1,split = ",")[[1]])[1:as.numeric(input$NumCol)]
# #         x1 <- x1 + S[, j1]
# #         xmat[[i]] <- x1
# #         tvec[i] <- tt
# #         tt <- tvec[i]
# #         i <- i+1
# #         }
# #       xmat <- t(as.data.frame(xmat,row.names = strsplit(input$text,split = ",")[[1]]))
# #       BM <- append(BM,list(a=as.integer(tail(xmat[,input$spec],1))))
# #       j <- j+1
# #       }
# #       return( hist(unlist(BM),freq = FALSE, xlab = "# Molecules", main = paste("Histogram of" , spec_n())))
# #       } else {
# #         return(NULL)
# #       }
# #   })
# # #pt3 <-
# output$summ <- renderPlot({
#   BM <- list();
#   xmat <- list()
#   tt <- 0
#   tvec <- c();
#   S <- t(matrix(as.numeric(strsplit(text_2(), split = ",")[[1]])-as.numeric(strsplit(text_4(), split = ",")[[1]]),ncol = as.numeric(Num_Col()) ,nrow = as.numeric(Num_Row()),byrow=TRUE))
#   h1 <- eval(eval(parse(text = paste('substitute(c(',text_5(),'), setNames(as.list(c(',text_3(),')),strsplit("',text_6(), '",split = ",")[[1]]))', sep=''))))
#   x1 <- as.numeric(strsplit(text_3(),split = ",")[[1]])[1:as.numeric(Num_Col())]
#   xmat[[1]] <- x1
#   tvec[1] <- 0
#   tt <- tt + rexp(1, sum(h1))
#   x2 <- as.numeric(strsplit(text_3(),split = ",")[[1]])[(as.numeric(Num_Col())+1):(as.numeric(Num_Col())+as.numeric(Num_Row()))]
#   j1 <- sample(as.numeric(Num_Row()), 1, prob = h1)
#   x1 <- x1 + S[, j1]
#   xmat[[2]] <- x1
#   tvec[2] <- tt
#   i <- 3
#   while(tt < time_h()) {
#     #for (i in 3:input$time) {
#     x1 <- paste(c(x1,x2),collapse = ",")
#     h1 <- eval(eval(parse(text = paste('substitute(c(',text_5(),'), setNames(as.list(c(',x1,')),strsplit("',text_6(), '",split = ",")[[1]]))', sep=''))))
#     tt <- tt + rexp(1, sum(h1))
#     j1 <- sample(as.numeric(Num_Row()), 1, prob = h1)
#     x1 <- as.numeric(strsplit(x1,split = ",")[[1]])[1:as.numeric(Num_Col())]
#     x1 <- x1 + S[, j1]
#     xmat[[i]] <- x1
#     tvec[i] <- tt
#     tt <- tvec[i]
#     i <- i+1
#     }
#   xmat <- t(as.data.frame(xmat,row.names = strsplit(text_n(),split = ",")[[1]]))
#   BM <- list(a=as.integer(xmat[,spec_n()]))
#   j <- 1
#   for (j in 1:(as.numeric(sims_t())-1)){
#     xmat <- list()
#     tt <- 0
#     tvec <- c();
#     S <- t(matrix(as.numeric(strsplit(text_2(), split = ",")[[1]])-as.numeric(strsplit(text_4(), split = ",")[[1]]),ncol = as.numeric(Num_Col()) ,nrow = as.numeric(Num_Row()),byrow=TRUE))
#     h1 <- eval(eval(parse(text = paste('substitute(c(',text_5(),'), setNames(as.list(c(',text_3(),')),strsplit("',text_6(), '",split = ",")[[1]]))', sep=''))))
#     x1 <- as.numeric(strsplit(text_3(),split = ",")[[1]])[1:as.numeric(Num_Col())]
#     xmat[[1]] <- x1
#     tvec[1] <- 0
#     tt <- tt + rexp(1, sum(h1))
#     x2 <- as.numeric(strsplit(text_3(),split = ",")[[1]])[(as.numeric(Num_Col())+1):(as.numeric(Num_Col())+as.numeric(Num_Row()))]
#     j1 <- sample(as.numeric(Num_Row()), 1, prob = h1)
#     x1 <- x1 + S[, j1]
#     xmat[[2]] <- x1
#     tvec[2] <- tt
#     i <- 3
#     while(tt < time_h()) {
#       #for (i in 3:input$time) {
#       x1 <- paste(c(x1,x2),collapse = ",")
#       h1 <- eval(eval(parse(text = paste('substitute(c(',text_5(),'), setNames(as.list(c(',x1,')),strsplit("',text_6(), '",split = ",")[[1]]))', sep=''))))
#       tt <- tt + rexp(1, sum(h1))
#       j1 <- sample(as.numeric(Num_Row()), 1, prob = h1)
#       x1 <- as.numeric(strsplit(x1,split = ",")[[1]])[1:as.numeric(Num_Col())]
#       x1 <- x1 + S[, j1]
#       xmat[[i]] <- x1
#       tvec[i] <- tt
#       tt <- tvec[i]
#       i <- i+1
#       }
#     xmat <- t(as.data.frame(xmat,row.names = strsplit(text_n(),split = ",")[[1]]))
#     BM <- append(BM,list(a=as.integer(xmat[,spec_n()])))
#     j <- j+1
#     }
#   plot(unlist(BM),type="n",xlim=c(1,max(sapply(BM,length))),xlab="# Reactions",ylab=input$spec, main=title_r())
#   rect(par("usr")[1], par("usr")[3],
#        par("usr")[2], par("usr")[4],
#        col = "#ebebeb")
#   # Grid blanco
#   grid(nx = NULL, ny = NULL,
#        col = "white", lwd = 2)
#   mapply(lines,BM,col=seq_along(BM),lty=2)})
#    output$histo = renderPlot({pt2()})
# #   output$conf =  renderPlot({pt3()})
# #     input$do3
# #     if (input$do3){
# #       BM <- list()
# #       xmat <- list()
# #       tt <- 0
# #       tvec <- c();
# #       S <- t(matrix(as.numeric(strsplit(input$text2, split = ",")[[1]])-as.numeric(strsplit(input$text4, split = ",")[[1]]),ncol = as.numeric(input$NumCol) ,nrow = as.numeric(input$NumRow),byrow=TRUE))
# #       h1 <- eval(eval(parse(text = paste('substitute(c(',input$text5,'), setNames(as.list(c(',input$text3,')),strsplit("',input$text6, '",split = ",")[[1]]))', sep=''))))
# #       x1 <- as.numeric(strsplit(input$text3,split = ",")[[1]])[1:as.numeric(input$NumCol)]
# #       xmat[[1]] <- x1
# #       tvec[1] <- 0
# #       tt <- tt + rexp(1, sum(h1))
# #       x2 <- as.numeric(strsplit(input$text3,split = ",")[[1]])[(as.numeric(input$NumCol)+1):(as.numeric(input$NumCol)+as.numeric(input$NumRow))]
# #       j1 <- sample(as.numeric(input$NumRow), 1, prob = h1)
# #       x1 <- x1 + S[, j1]
# #       xmat[[2]] <- x1
# #       tvec[2] <- tt
# #       i <- 3
# #       while(tt < input$time) {
# #         #for (i in 3:input$time) {
# #         x1 <- paste(c(x1,x2),collapse = ",")
# #         h1 <- eval(eval(parse(text = paste('substitute(c(',input$text5,'), setNames(as.list(c(',x1,')),strsplit("',input$text6, '",split = ",")[[1]]))', sep=''))))
# #         tt <- tt + rexp(1, sum(h1))
# #         j1 <- sample(as.numeric(input$NumRow), 1, prob = h1)
# #         x1 <- as.numeric(strsplit(x1,split = ",")[[1]])[1:as.numeric(input$NumCol)]
# #         x1 <- x1 + S[, j1]
# #         xmat[[i]] <- x1
# #         tvec[i] <- tt
# #         tt <- tvec[i]
# #         i <- i+1
# #       }
# #       xmat <- t(as.data.frame(xmat,row.names = strsplit(input$text,split = ",")[[1]]))
# #       BM <- list(a=as.integer(tail(xmat[,input$spec],1)))
# #       j <- 1
# #       for (j in 1:(as.numeric(input$sims)-1)){
# #         xmat <- list()
# #         tt <- 0
# #         tvec <- c();
# #         S <- t(matrix(as.numeric(strsplit(input$text2, split = ",")[[1]])-as.numeric(strsplit(input$text4, split = ",")[[1]]),ncol = as.numeric(input$NumCol) ,nrow = as.numeric(input$NumRow),byrow=TRUE))
# #         h1 <- eval(eval(parse(text = paste('substitute(c(',input$text5,'), setNames(as.list(c(',input$text3,')),strsplit("',input$text6, '",split = ",")[[1]]))', sep=''))))
# #         x1 <- as.numeric(strsplit(input$text3,split = ",")[[1]])[1:as.numeric(input$NumCol)]
# #         xmat[[1]] <- x1
# #         tvec[1] <- 0
# #         tt <- tt + rexp(1, sum(h1))
# #         x2 <- as.numeric(strsplit(input$text3,split = ",")[[1]])[(as.numeric(input$NumCol)+1):(as.numeric(input$NumCol)+as.numeric(input$NumRow))]
# #         j1 <- sample(as.numeric(input$NumRow), 1, prob = h1)
# #         x1 <- x1 + S[, j1]
# #         xmat[[2]] <- x1
# #         tvec[2] <- tt
# #         i <- 3
# #         while(tt < input$time) {
# #           #for (i in 3:input$time) {
# #           x1 <- paste(c(x1,x2),collapse = ",")
# #           h1 <- eval(eval(parse(text = paste('substitute(c(',input$text5,'), setNames(as.list(c(',x1,')),strsplit("',input$text6, '",split = ",")[[1]]))', sep=''))))
# #           tt <- tt + rexp(1, sum(h1))
# #           j1 <- sample(as.numeric(input$NumRow), 1, prob = h1)
# #           x1 <- as.numeric(strsplit(x1,split = ",")[[1]])[1:as.numeric(input$NumCol)]
# #           x1 <- x1 + S[, j1]
# #           xmat[[i]] <- x1
# #           tvec[i] <- tt
# #           tt <- tvec[i]
# #           i <- i+1
# #         }
# #         xmat <- t(as.data.frame(xmat,row.names = strsplit(input$text,split = ",")[[1]]))
# #         BM <- append(BM,list(a=as.integer(tail(xmat[,input$spec],1))))
# #         j <- j+1
# #       }
# #       BM2 <- list();
# #       BM2<-list(colMeans(do.call(rbind,BM)));
# #       BM2<-append(BM2,list(colMeans(do.call(rbind,BM))-3*colSds(do.call(rbind,BM))));
# #       BM2<-append(BM2,list(colMeans(do.call(rbind,BM))+3*colSds(do.call(rbind,BM))));
# #       plot(unlist(BM2),type="n",xlim=c(1,max(sapply(BM2,length))),xlab="# Reactions",ylab=input$spec);
# #       rect(par("usr")[1], par("usr")[3],
# #            par("usr")[2], par("usr")[4],
# #            col = "#ebebeb");
# #       # Grid blanco
# #       grid(nx = NULL, ny = NULL,
# #            col = "white", lwd = 2);
# #       #return( {
# #       mapply(lines,BM2,col=seq_along(BM2),lty=2);
# #       legend("topleft",legend=c("Sample mean", "Sample mean minus 3 sample SDs", "Sample mean plus 3 sample SDs"), col=c("black", "red", "green"),lty=2, cex=0.4,bg="#ebebeb")
# #       #})
# #     } else {
# #       return(NULL)
# #     }
# #   })})
#   }
# )
#
# shinyApp(ui = ui, server = server)
#
#
#
# # library(shiny)
# # library(ggplot2)
# # library(gridExtra)
# #
# # u <- shinyUI(fluidPage(
# #   titlePanel("title panel"),
# #   sidebarLayout(position = "left",
# #                 sidebarPanel("sidebar panel",
# #                              checkboxInput("donum1", "Make #1 plot", value = T),
# #                              checkboxInput("donum2", "Make #2 plot", value = F),
# #                              checkboxInput("donum3", "Make #3 plot", value = F),
# #                              sliderInput("wt1","Weight 1",min=1,max=10,value=1),
# #                              sliderInput("wt2","Weight 2",min=1,max=10,value=1),
# #                              sliderInput("wt3","Weight 3",min=1,max=10,value=1)
# #                 ),
# #                 mainPanel("main panel",
# #                           column(6,plotOutput(outputId="plotgraph", width="500px",height="400px"))
# #                 ))))
# #
# # s <- shinyServer(function(input, output)
# # {
# #   set.seed(123)
# #   pt1 <- reactive({
# #     if (!input$donum1) return(NULL)
# #     qplot(rnorm(500),fill=I("red"),binwidth=0.2,main="plotgraph1")
# #   })
# #   pt2 <- reactive({
# #     if (!input$donum2) return(NULL)
# #     qplot(rnorm(500),fill=I("blue"),binwidth=0.2,main="plotgraph2")
# #   })
# #   pt3 <- reactive({
# #     if (!input$donum3) return(NULL)
# #     qplot(rnorm(500),fill=I("green"),binwidth=0.2,main="plotgraph3")
# #   })
# #   output$plotgraph = renderPlot({
# #     ptlist <- list(pt1(),pt2(),pt3())
# #     wtlist <- c(input$wt1,input$wt2,input$wt3)
# #     # remove the null plots from ptlist and wtlist
# #     to_delete <- !sapply(ptlist,is.null)
# #     ptlist <- ptlist[to_delete]
# #     wtlist <- wtlist[to_delete]
# #     if (length(ptlist)==0) return(NULL)
# #
# #     grid.arrange(grobs=ptlist,widths=wtlist,ncol=length(ptlist))
# #   })
# # })
# # shinyApp(u,s)
