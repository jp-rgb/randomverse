# #
# # This is a Shiny web application. You can run the application by clicking
# # the 'Run App' button above.
# #
# # Find out more about building applications with Shiny here:
# #
# #    http://shiny.rstudio.com/
# #
#
# library(shiny)
# library(tidyverse)
# library(ggfortify)
#
# # # Define UI for application that draws a histogram
# # ui <- fluidPage(
# #
# #     # Application title
# #     titlePanel("Old Faithful Geyser Data"),
# #
# #     # Sidebar with a slider input for number of bins
# #     sidebarLayout(
# #         sidebarPanel(
# #             sliderInput("bins",
# #                         "Number of bins:",
# #                         min = 1,
# #                         max = 50,
# #                         value = 30),
# #             numericInput("color",
# #                          "Color de histograma:",
# #                          min=1,
# #                          max=5,
# #                          value=3)
# #         ),
# #
# #         # Show a plot of the generated distribution
# #         mainPanel(
# #            plotOutput("distPlot")
# #         )
# #     )
# # )
# #
# # # Define server logic required to draw a histogram
# # server <- function(input, output) {
# #
# #     output$distPlot <- renderPlot({
# #         # generate bins based on input$bins from ui.R
# #         x    <- faithful[, 2]
# #         bins <- seq(min(x), max(x), length.out = input$bins + 1)
# #
# #         # draw the histogram with the specified number of bins
# #         hist(x, breaks = bins, col = input$color, border = 'white',
# #              xlab = 'Waiting time to next eruption (in mins)',
# #              main = 'Histogram of waiting times')
# #     })
# # }
# #
# # # Run the application
# # shinyApp(ui = ui, server = server)
#
# ui <- fluidPage(
#
#   titlePanel(h4("Serie de tiempo múltiple")),
#
#   sidebarLayout(
#     sidebarPanel(
#       checkboxInput("view", h6("Facets"), value = FALSE, width = NULL)
#
#     ),
#
#     mainPanel(
#       tabsetPanel(
#         tabPanel("Stochastic", plotOutput("stoch")),
#         tabPanel("Deterministic", plotOutput("det"))
#       )
#     )
#   )
# )
#
# server <- function(input,output){
#
#   output$stoch<-renderPlot({
#     N= list()
#     N$M=c(x1=0,x2=1,x3=2,x4=10,x5=12)
#     N$Pre= matrix(c(0, 1, 0, 0, 1,
#                     1, 0, 0, 0, 0,
#                     0, 1, 0, 0, 0,
#                     0, 0, 1, 0, 0,
#                     0, 0, 0, 2, 0,
#                     0, 0, 0, 0, 1,
#                     0, 0, 1, 0, 0,
#                     0, 0, 0, 1, 0),ncol=5,byrow=TRUE)
#     N$Post= matrix(c(1, 0, 0, 0, 0,
#                      0, 1, 0, 0, 1,
#                      0, 1, 1, 0, 0,
#                      0, 0, 1, 1, 0,
#                      0, 0, 0, 0, 1,
#                      0, 0, 0, 2, 0,
#                      0, 0, 0, 0, 0,
#                      0, 0, 0, 0, 0),ncol=5,byrow=TRUE)
#     N$h= function(x,t,th=c(th1=1,th2=10,th3=0.01,th4=10,th5=1,th6=1,th7=0.1,th8=0.01))
#     {
#       with( as.list(c(x,th)),{
#         #GeneP2:=x1, Gene:=x2, RNA:=x3, P:=x4, P2:=x5
#         return(c(th1*x2*x5, th2*x1, th3*x2, th4*x3, th5*0.5*x4*(x4-1), th6*x5, th7*x3, th8*x4))
#       })
#     }
#     tt = 0
#     x = N$M
#     S = t(N$Post - N$Pre)
#     u = nrow(S)
#     v = ncol(S)
#     tvec=c();
#     tvec[1] = 0
#     xmat = list()
#     xmat[[1]] = x
#     #i=1
#     i = 2
#     while(tt<1)
#       #for (i in 1:n)
#     {
#       h = N$h(x, tt)
#       tt = tt + rexp(1, sum(h))
#       j = sample(v, 1, prob = h)
#       x = x + S[, j]
#       tvec[i] = tt
#       xmat[[i]] <- x
#       i=i+1
#     }
#     xmat = t(as.data.frame(xmat))
#     autoplot(ts(xmat),facets = input$view, main="Auto-regulatory genetic network")
#   })
#
#   output$det<-renderPlot({
#     N= list()
#     N$M=c(x1=0,x2=1,x3=2,x4=10,x5=12)
#     N$Pre= matrix(c(0, 1, 0, 0, 1,
#                     1, 0, 0, 0, 0,
#                     0, 1, 0, 0, 0,
#                     0, 0, 1, 0, 0,
#                     0, 0, 0, 2, 0,
#                     0, 0, 0, 0, 1,
#                     0, 0, 1, 0, 0,
#                     0, 0, 0, 1, 0),ncol=5,byrow=TRUE)
#     N$Post= matrix(c(1, 0, 0, 0, 0,
#                      0, 1, 0, 0, 1,
#                      0, 1, 1, 0, 0,
#                      0, 0, 1, 1, 0,
#                      0, 0, 0, 0, 1,
#                      0, 0, 0, 2, 0,
#                      0, 0, 0, 0, 0,
#                      0, 0, 0, 0, 0),ncol=5,byrow=TRUE)
#     N$h= function(x,t,th=c(th1=1,th2=10,th3=0.01,th4=10,th5=1,th6=1,th7=0.1,th8=0.01))
#     {
#       with( as.list(c(x,th)),{
#         #GeneP2:=x1, Gene:=x2, RNA:=x3, P:=x4, P2:=x5
#         return(c(th1*x2*x5-th2*x1,th2*x1-th1*x5*x2,th3*x2-th7*x3+th4*x3,th4*x3+2*th6*x5-2*th5*x5-th8*x4,th2*x1-th1*x5*x2))
#       })
#     }
#     xmat = list()
#     tt = 0
#     tvec=c();
#     x = N$M
#     xmat[[1]] = x
#     tvec[1] = 0
#     dt = 0.001
#     tt = tt + dt
#     x = x + N$h(x,tt)*dt
#     xmat[[2]] = x
#     tvec[2] = tt
#     i=3
#     # n=as.numeric(input$time)/dt
#     while(tt<1) {
#       #for (i in 3:input$time) {
#       h = N$h(x, tt)
#       x = x + N$h(x,tt)*dt
#       tt = tt + dt
#       xmat[[i]] = x
#       tvec[i] = tt
#       tt=tvec[i]
#       i=i+1
#     }
#     xmat = t(as.data.frame(xmat))
#     autoplot(ts(xmat),facets = input$view, main= "Auto-regulatory genetic network")
#   }
#   )
#
#
# }
#
# shinyApp(ui = ui, server = server)

# # Definir UI para aplicación que grafica histograma
# ui <- fluidPage(
#   # Título de la aplicación
#   titlePanel("Old Faithful Geyser Data"),
#   # Barra lateral con deslizador para número de bins igual al input
#   sidebarLayout(
#     sidebarPanel(
#       sliderInput("bins",
#                   "Number of bins:",
#                   min = 1,
#                   max = 50,
#                   value = 30)
#     ),
#     # Graficar la distribución generada
#     mainPanel(
#       plotOutput("distPlot")
#     )
#   )
# )
#
# server <- function(input, output) {
#   output$distPlot <- renderPlot({
#     # generar bins tomando input$bins de ui.R
#     x    <- faithful[, 2]
#     bins <- seq(min(x), max(x), length.out = input$bins + 1)
#     # graficar histograma con el número especificado de bins
#     hist(x, breaks = bins, col = 'darkgray', border = 'white')
#   })
# }
#
# shinyApp(ui = ui, server = server)
library(shiny)
library(tidyverse)
#library(ggfortify)

ui <- fluidPage(

  titlePanel(h4("An Introduction to the randomverse")),

  sidebarLayout(
    sidebarPanel(h3("Model parameters"),
                 textInput("text5", label = h6("Input function body (comma delimited, no blanks)"), value = "th1*x1-th2*x1*x2,th2*x1*x2-th3*x2"),
                 textInput("text6", label = h6("Input function arguments (comma delimited, no blanks)"), value = "x1,x2,th1,th2,th3"),
                 textInput("text3", label = h6("Input initial markings with hazards (comma delimited, no blanks)"), value = "50,100,1,0.005,0.6"),
                 textInput("text4", label = h6("Input Pre matrix (comma delimited, no blanks)"), value = "1,0,1,1,0,1"),
                 textInput("text2", label = h6("Input Post matrix (comma delimited, no blanks)"), value = "2,0,0,2,0,0"),
                 selectInput('NumRow',label = h6('Reactions'), choices = c(2:30),selected = 3),
                 selectInput('NumCol',label = h6('Species'), choices = c(2:30),selected = 2),
                 textInput("text", label = h6("Input species names (comma delimited, no blanks)"), value = "Prey,Predator"),
                 textInput("title", label = h6("Input model name"), value = "Lotka-Volterra system"),
                 h3("Simulation summary"),
                 numericInput("sims", label = h6("Trajectories"),2,min = 2,max = 10000),                     textInput("spec", label = h6("Select species"), value = "P"),
                 #checkboxInput("do2", "Histogram", value = F),
                 #checkboxInput("do3", "Confidence bands", value = F),
                 #checkboxInput("donum1", "Make #1 plot", value = T),
                 checkboxInput("donum2", "Histogram", value = F),
                 #checkboxInput("donum3", "Confidence bands", value = F),
                 numericInput("time", label = h6("Time horizon"),10,min = 0,max = 10000),
                 checkboxInput("facet", "Facet", value = F),
                 submitButton("Plot")
    ),

    mainPanel(
      tabsetPanel(
        tabPanel("Deterministic", plotOutput("det")),
        tabPanel("Stochastic", plotOutput("stoch")),
        tabPanel("Summary",
                 #plotOutput("summ")}
                 splitLayout(cellWidths = c("40%", "30%", "30%"), plotOutput("summ"), plotOutput("histo"), plotOutput("conf")))

      )
    )
  )
)


server <- function(input,output){



#shinyApp(ui = ui, server = server)

# checkboxInput("view", h6("Facets"), value = FALSE, width = NULL),

# tabPanel("Stochastic", plotOutput("stoch")),
# tabPanel("Deterministic", plotOutput("det"))

output$stoch<-renderPlot({
  N= list()
  N$M=c(x1=0,x2=1,x3=2,x4=10,x5=12)
  N$Pre= matrix(c(0, 1, 0, 0, 1,
                  1, 0, 0, 0, 0,
                  0, 1, 0, 0, 0,
                  0, 0, 1, 0, 0,
                  0, 0, 0, 2, 0,
                  0, 0, 0, 0, 1,
                  0, 0, 1, 0, 0,
                  0, 0, 0, 1, 0),ncol=5,byrow=TRUE)
  N$Post= matrix(c(1, 0, 0, 0, 0,
                   0, 1, 0, 0, 1,
                   0, 1, 1, 0, 0,
                   0, 0, 1, 1, 0,
                   0, 0, 0, 0, 1,
                   0, 0, 0, 2, 0,
                   0, 0, 0, 0, 0,
                   0, 0, 0, 0, 0),ncol=5,byrow=TRUE)
  N$h= function(x,t,th=c(th1=1,th2=10,th3=0.01,th4=10,th5=1,th6=1,th7=0.1,th8=0.01))
  {
    with( as.list(c(x,th)),{
      #GeneP2:=x1, Gene:=x2, RNA:=x3, P:=x4, P2:=x5
      return(c(th1*x2*x5, th2*x1, th3*x2, th4*x3, th5*0.5*x4*(x4-1), th6*x5, th7*x3, th8*x4))
    })
  }
  tt = 0
  x = N$M
  S = t(N$Post - N$Pre)
  u = nrow(S)
  v = ncol(S)
  tvec=c();
  tvec[1] = 0
  xmat = list()
  xmat[[1]] = x
  #i=1
  i = 2
  while(tt<1)
    #for (i in 1:n)
  {
    h = N$h(x, tt)
    tt = tt + rexp(1, sum(h))
    j = sample(v, 1, prob = h)
    x = x + S[, j]
    tvec[i] = tt
    xmat[[i]] <- x
    i=i+1
  }
  xmat = t(as.data.frame(xmat))
  data_long<-gather(cbind(tvec,as.data.frame(ts(xmat))),species,molecules,colnames(xmat))
  ggplot(data_long)+geom_line(aes(x=tvec,y=molecules,color=species))
  #plot(ts(xmat))
  # my_data<-tibble(
  #   cbind(tvec,as.data.frame(ts(xmat)[,1]))
  # )
  # ggplot(my_data)+geom_line(aes(x=tvec,y=x))
  #ggplot(cbind(tvec,as.data.frame(ts(xmat))))+(aes(t=tvec,y=colnames(xmat)[1]))
  #autoplot(ts(xmat),facets = input$view, main="Auto-regulatory genetic network")
})

output$det<-renderPlot({
  N= list()
  N$M=c(x1=0,x2=1,x3=2,x4=10,x5=12)
  N$Pre= matrix(c(0, 1, 0, 0, 1,
                  1, 0, 0, 0, 0,
                  0, 1, 0, 0, 0,
                  0, 0, 1, 0, 0,
                  0, 0, 0, 2, 0,
                  0, 0, 0, 0, 1,
                  0, 0, 1, 0, 0,
                  0, 0, 0, 1, 0),ncol=5,byrow=TRUE)
  N$Post= matrix(c(1, 0, 0, 0, 0,
                   0, 1, 0, 0, 1,
                   0, 1, 1, 0, 0,
                   0, 0, 1, 1, 0,
                   0, 0, 0, 0, 1,
                   0, 0, 0, 2, 0,
                   0, 0, 0, 0, 0,
                   0, 0, 0, 0, 0),ncol=5,byrow=TRUE)
  N$h= function(x,t,th=c(th1=1,th2=10,th3=0.01,th4=10,th5=1,th6=1,th7=0.1,th8=0.01))
  {
    with( as.list(c(x,th)),{
      #GeneP2:=x1, Gene:=x2, RNA:=x3, P:=x4, P2:=x5
      return(c(th1*x2*x5-th2*x1,th2*x1-th1*x5*x2,th3*x2-th7*x3+th4*x3,th4*x3+2*th6*x5-2*th5*x5-th8*x4,th2*x1-th1*x5*x2))
    })
  }
  xmat = list()
  tt = 0
  tvec=c();
  x = N$M
  xmat[[1]] = x
  tvec[1] = 0
  dt = 0.001
  tt = tt + dt
  x = x + N$h(x,tt)*dt
  xmat[[2]] = x
  tvec[2] = tt
  i=3
  # n=as.numeric(input$time)/dt
  while(tt<1) {
    #for (i in 3:input$time) {
    h = N$h(x, tt)
    x = x + N$h(x,tt)*dt
    tt = tt + dt
    xmat[[i]] = x
    tvec[i] = tt
    tt=tvec[i]
    i=i+1
  }
  xmat = t(as.data.frame(xmat))
  # data_long<-gather(cbind(tvec,as.data.frame(ts(xmat))),species,molecules,colnames(xmat))
  # ggplot(data_long)+geom_line(aes(x=tvec,y=molecules,color=species))
  plot(ts(xmat))
  # my_data<-tibble(
  #   cbind(tvec,as.data.frame(ts(xmat)[,1]))
  # )
  # ggplot(my_data)+geom_line(aes(x=tvec,y=x))
  #autoplot(ts(xmat),facets = input$view, main= "Auto-regulatory genetic network")
}
)
}

shinyApp(ui = ui, server = server)
