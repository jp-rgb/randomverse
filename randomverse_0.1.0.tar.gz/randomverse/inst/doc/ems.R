## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ----ems1, echo=FALSE, message=FALSE------------------------------------------
d <- cbind( Species = c("Gen", "Ácido ribonucleico (ARN)", "Proteina"), termino = c("$g$","$r$","$P$"))
colnames(d) <- c("Especie", "término")
#knitr::kable(d)
library(kableExtra)
kbl(d, caption = "Representación algebraica de especies biológicas") %>%
  kable_styling() 

## ----ems2, echo=FALSE, message=FALSE------------------------------------------
d <- cbind( reacc = c("Tanscripción", "Traducción"), g = c(1,0), r = c(0,1), P = c(0,0))
colnames(d) <- c("Reacción", "$g$","$r$", "$P$")
#knitr::kable(d)
library(kableExtra)
kbl(d, caption = "Representación matricial previa al evento ($Pre$)") %>%
  kable_styling() %>%
  add_header_above(c(" " = 1, "Especies" = 3))

## ----ems3, echo=FALSE, message=FALSE------------------------------------------
d <- cbind( reacc = c("Tanscripción", "Traducción"), g = c(1,0), r = c(1,1), P = c(0,1))
colnames(d) <- c("Reacción", "$g$","$r$", "$P$")
#knitr::kable(d)
library(kableExtra)
kbl(d, caption = "Representación matricial posterior al evento ($Post$)") %>%
  kable_styling() %>%
  add_header_above(c(" " = 1, "Especies" = 3))

## ----sessionInfo, echo=FALSE--------------------------------------------------
sessionInfo()

