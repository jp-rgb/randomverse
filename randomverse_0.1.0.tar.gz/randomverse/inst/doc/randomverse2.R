## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ----ar, fig.cap="Auto-regulatory genetic reaction network. A loop is observed in the binding of gene to dimmer producing repression with a certain probability before initiating the system. Dimmeristaion of a protein and degradation are also included in the process.", fig.wide=TRUE, echo=FALSE, message=FALSE----
library(diagram)
names <- c("g", "", "r", "", "", "g.P2", "", "" 
           , "", "P2", "P", "", ""
)
M <- matrix(nrow = 13, ncol = 13, byrow = TRUE, data = c(
  #"g", "", "r", "", "", "g.P2", "", "", "", "P2", "P", "", ""
  0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, #g
  1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, #""
  0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, #r
  0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, #""
  0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, #""
  0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, #"g.P2"
  0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, #""
  1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, #""
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, #""
  0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, #"P"
  0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 2, #"P2"
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, #""
  0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0  #""
))
pp <- plotmat(M, pos = c(4, 1, 2, 2, 3, 1), name = names, arr.type = "simple", 
              arr.length=0.3, arr.width=0.1,box.lwd=1, box.prop=0.1, 
              box.size=0.09, cex.txt=0.8, lwd=1, self.cex=0.6,
              self.shiftx=0.17, self.shifty=-0.01,shadow.size = 0,curve#=0
              =matrix(nrow = 13, ncol = 13, byrow = TRUE, data = c(
                #"g", "", "r", "", "", "g.P2", "", "", "", "P2", "P", "", ""
                0, .17, 0, 0, -.17, 0, 0, 0, 0, 0, 0, 0, 0, #g
                .17, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, #""
                0, 0, 0, 0, 0, 0, .17, 0, 0, 0, 0, 0, 0, #r
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, #""
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, #""
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, #"g.P2"
                0, 0, .17, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, #""
                .2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, #""
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, #""
                0, 0, 0, 0, -.14, 0, 0, 0, 0, 0, 0, 0, 0, #"P2"
                0, 0, 0, 0, 0, 0, .17, 0, 0, 0, 0, 0, 0, #"P"
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, #""
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0  #""
              )), box.type = c("ellipse","rect","ellipse",
                               "rect","rect","ellipse",
                               "rect","rect","rect",
                               "ellipse","ellipse","rect",
                               "rect"), #arr.pos=.7
              )

## ----artab, echo=FALSE, message=FALSE-----------------------------------------
d <- cbind( Species = c("Repression", "Reverse repression", "Transcription", "Translation", "Dimerisation", "Dissociation", "mRNA degradation", "Protein degradation"), gP2 = c("",1,"","","","","",""), g = c(1,"",1,"","","","",""), r = c("","","",1,"","",1,""), P = c("","","","",2,"","",1), P2 = c(1,"","","","",1,"",""), gP2 = c(1,"","","","","","",""), g = c("",1,1,"","","","",""), r = c("","",1,1,"","","",""), P = c("","","",1,"",2,"",""), P2 = c("",1,"","",1,"","",""))
colnames(d) <- c("Species", "$g⋅P_2$", "$g$", "$r$", "$P$", "$P_2$", "$g⋅P_2$", "$g$", "$r$", "$P$", "$P_2$")
#knitr::kable(d)
library(kableExtra)
kbl(d, caption = "Tabular representation of auto-regulatory system.") %>%
  kable_styling() %>%
  add_header_above(c(" " = 1, "Reactants ( Pre)" = 5, "Products (Post)" = 5))

## ----arOE, echo=FALSE, message=FALSE------------------------------------------
d <- cbind( Species = c("Repression", "Reverse repression", "Transcription", "Translation", "Dimerisation", "Dissociation", "mRNA degradation", "Protein degradation"), gP2 = c(1,-1,0,0,0,0,0,0), g = c(-1,1,0,0,0,0,0,0), r = c(0,0,1,0,0,0,-1,0), P = c(0,0,0,1,-2,2,0,-1), P2 = c(-1,1,0,0,1,-1,0,0))
colnames(d) <- c("Species", "$g⋅P_2$", "$g$", "$r$", "$P$", "$P_2$")
kbl(d, caption = "Overall effect of each reaction on the marking of the auto-regulatory network.") %>%
  kable_styling()

## ----arapp, echo=FALSE, message=FALSE, fig.cap="Shiny components of the auto-regulatory genetic network. Stochastic model."----
d <- cbind( Component = c("Function Body", "Function Arguments", "Initial Markings with Hazards", "Pre matrix", "Post matrix", "Reactions", "Species", "Species names", "Model name"), Input = c("$\\texttt{th1*x2*x5,th2*x1,th3*x2,th4*x3,th5*0.5*x4*(x4-1),th6*x5,th7*x3,th8*x4}$", "$\\texttt{x1,x2,x3,x4,x5,th1,th2,th3,th4,th5,th6,th7,th8}$", "$\\texttt{0,1,2,10,12,1,10,0.01,10,1,1,0.1,0.01}$", "$\\texttt{0,1,0,0,1,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,2,0,0,0,0,0,1,0,0,1,0,0,0,0,0,1,0}$", "$\\texttt{1,0,0,0,0,0,1,0,0,1,0,1,1,0,0,0,0,1,1,0,0,0,0,0,1,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0}$", "8", "5", "g⋅P2,g,r,P,P2", "Auto-regulatory genetic network"))
#colnames(d) <- c("Species", "$g⋅P_2$", "$g$", "$r$", "$P$", "$P_2$")
kbl(d
    , caption = "Shiny components of the auto-regulatory genetic network. Stochastic model."
    ) %>%
  kable_styling()

## ----arfig, echo=FALSE, fig.cap="A simulated realisation of the discrete stochastic dynamics of the genetic auto-regulatory network model, for a period of 700 seconds.", fig.wide=TRUE, fig.align="center"----
knitr::include_graphics("ar.png")

## ----arfacet, echo=FALSE, fig.cap="Facet view of the genetic auto-regulatory network", fig.wide=TRUE, fig.align="center"----
knitr::include_graphics("AR_facet.png")

## ----lvapp, echo=FALSE, message=FALSE, fig.cap="Shiny components of the Lotka-Volterra System. Stochastic model."----
d <- cbind( Component = c("Function Body", "Function Arguments", "Initial Markings with Hazards", "Pre matrix", "Post matrix", "Reactions", "Species", "Species names", "Model name"), Input = c("$\\texttt{th1*x1,th2*x1*x2,th3*x2}$", "$\\texttt{x1,x2,th1,th2,th3}$", "$\\texttt{50,100,1,0.05,0.6}$", "$\\texttt{1,0,1,1,0,1}$", "$\\texttt{2,0,0,2,0,0}$", "3", "2", "Prey,Predator", "Lotka-Volterra System"))
kbl(d
    , caption = "Shiny components of the Lotka-Volterra system. Stochastic model."
    ) %>%
  kable_styling()

## ----lvfig, echo=FALSE, fig.cap="A single realisation of a stochastic LV process. The state of the system is initialised to 50 prey and 100 predators, and the stochastic rate constants are c = (1, 0.005, 0.6)", fig.wide=TRUE, fig.align="center"----
knitr::include_graphics("LV.png")

## ----dkapp, echo=FALSE, message=FALSE, fig.cap="Shiny components of the Lotka-Volterra System. Stochastic model"----
d <- cbind( Component = c("Function Body", "Function Arguments", "Initial Markings with Hazards", "Pre matrix", "Post matrix", "Reactions", "Species", "Species names", "Model name"), Input = c("$\\texttt{th1*x1*(x1-1)/2,th2*x2}$", "$\\texttt{x1,x2,th1,th2}$", "$\\texttt{301,0,1.66e-3,0.2}$", "$\\texttt{2,0,0,1}$", "$\\texttt{0,1,2,0}$", "2", "2", "Protein,Dimer", "Dimerisation kinetics"))
kbl(d
    , caption = "Shiny components of the dimeristaion kinetics of a protein. Stochastic model."
    ) %>%
  kable_styling()

## ----dkfig, echo=FALSE, fig.cap="A simulated realisation of the discrete stochastic dynamics of the dimerisation kinetics model", fig.wide=TRUE, fig.align="center"----
knitr::include_graphics("DK.png")

## ----mmapp, echo=FALSE, message=FALSE, fig.cap="Shiny components of the Lotka-Volterra System. Stochastic model."----
d <- cbind( Component = c("Function Body", "Function Arguments", "Initial Markings with Hazards", "Pre matrix", "Post matrix", "Reactions", "Species", "Species names", "Model name"), Input = c("$\\texttt{th1*x1*x2,th2*x3,th3*x3}$", "$\\texttt{x1,x2,x3,x4,th1,th2,th3}$", "$\\texttt{301,120,100,10,0.00166,1e-04,0.1}$", "$\\texttt{1,1,0,0,0,0,1,0,0,0,1,0}$", "$\\texttt{0,0,1,0,1,1,0,0,0,1,0,1}$", "3", "4", "S,E,SE,P", "Michaelis-Menten enzyme kinetics"))
kbl(d
    , caption = "Shiny components of the Michaelis-Menten enzyme kinetics. Stochastic model."
    ) %>%
  kable_styling()

## ----mmfig, echo=FALSE, fig.cap="A simulated realisation of the discrete stochastic dynamics of the Michaelis–Menten kinetics model.", fig.wide=TRUE, fig.align="center"----
knitr::include_graphics("MM.png")

## ----ardet, echo=FALSE, fig.cap="Deterministic version of the Auto-regulatory network.", fig.wide=TRUE, fig.align="center"----
knitr::include_graphics("AR_det.png")

## ----lvdet, echo=FALSE, fig.cap="Deterministic version of the Lotka-Volterra System.", fig.wide=TRUE, fig.align="center"----
knitr::include_graphics("LV_det.png")

## ----dkdet, echo=FALSE, fig.cap="Deterministic version of the Dimerisation kinetics model.", fig.wide=TRUE, fig.align="center"----
knitr::include_graphics("DK_det.png")

## ----mmdet, echo=FALSE, fig.cap="Deterministic version of the MIchaelis-Menten enzyme kinetics model.", fig.wide=TRUE, fig.align="center"----
knitr::include_graphics("MM_det.png")

## ----summ, echo=FALSE, fig.cap="Trajectories of a predator species of the Lotka-Volterra model."----
knitr::include_graphics("summ.png")

## ----hpred, echo=FALSE, fig.cap="Histogram of a predator species of the Lotka-Volterra model."----
knitr::include_graphics("hpred.png")

## ----ARsumm, echo=FALSE, fig.cap="Trajectories of a protein species of the auto-regulatory genetic network."----
knitr::include_graphics("ARsumm.png")

## ----hP, echo=FALSE, fig.cap="Histogram of a protein species of the auto-regulatory genetic network."----
knitr::include_graphics("ARhist.png")

## ---- echo=FALSE--------------------------------------------------------------
library(knitr);knitr::include_graphics("VIH_ar.png")

## ----sessionInfo, echo=FALSE--------------------------------------------------
sessionInfo()

